#!/usr/bin/env python3
"""AD5X LAN upload with explicit IFS mapping. No network call without --send."""
import argparse,base64,getpass,hashlib,http.client,ipaddress,json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
EXPECTED='0f461a6632ad2f70a296b3406ea979e76cf1a8c648729d30e96ce6ea80d36356'

def prepare(serial,code,start):
    path=ROOT/'IFS4_V3.gcode';data=path.read_bytes()
    if hashlib.sha256(data).hexdigest()!=EXPECTED:
        raise ValueError('Arquivo diferente do G-code verificado; envio cancelado.')
    mappings=json.loads((ROOT/'materialMappings.json').read_text())
    expected=[(0,1,'#FFFFFF'),(1,2,'#000000')]
    if [(m['toolId'],m['slotId'],m['toolMaterialColor']) for m in mappings]!=expected:
        raise ValueError('Mapeamento inesperado; envio cancelado.')
    boundary='----NetanyaAD5XIFS4Upload'
    body=(f'--{boundary}\r\nContent-Disposition: form-data; name="gcodeFile"; filename="{path.name}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+data+f'\r\n--{boundary}--\r\n'.encode())
    headers={'Content-Type':f'multipart/form-data; boundary={boundary}',
             'Content-Length':str(len(body)),'serialNumber':serial,'checkCode':code,
             'fileSize':str(len(data)),'printNow':str(start).lower(),
             'levelingBeforePrint':'true','flowCalibration':'false',
             'firstLayerInspection':'false','timeLapseVideo':'false',
             'useMatlStation':'true','gcodeToolCnt':'2',
             'materialMappings':base64.b64encode(json.dumps(mappings,separators=(',',':')).encode()).decode()}
    return body,headers

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host',help='IP privado da AD5X na mesma rede local')
    p.add_argument('--send',action='store_true',help='Enviar para a impressora; sem esta opcao apenas confere dados')
    p.add_argument('--start',action='store_true',help='Iniciar a impressao apos enviar (exige --send)')
    a=p.parse_args()
    if a.start and not a.send:p.error('--start exige --send')
    if not a.send:
        _,h=prepare('NOT_SENT','NOT_SENT',False)
        print(json.dumps({'mode':'offline; nenhuma conexao ou impressao',
              'file':'IFS4_V3.gcode','useMatlStation':h['useMatlStation'],
              'gcodeToolCnt':h['gcodeToolCnt'],
              'materialMappings':json.loads(base64.b64decode(h['materialMappings']))},indent=2));return
    if not a.host:p.error('--send exige --host IP_DA_IMPRESSORA')
    address=ipaddress.ip_address(a.host)
    if not address.is_private or address.is_loopback or address.is_unspecified or address.version!=4:
        p.error('Use o IPv4 privado da impressora na sua rede local.')
    serial=input('Numero de serie da AD5X: ').strip()
    code=getpass.getpass('Codigo de acesso LAN da AD5X (nao sera exibido nem salvo): ')
    if not serial or not code:raise ValueError('Serie e codigo sao necessarios; envio cancelado.')
    body,headers=prepare(serial,code,a.start)
    connection=http.client.HTTPConnection(str(address),8898,timeout=90)
    try:
        connection.request('POST','/uploadGcode',body=body,headers=headers)
        response=connection.getresponse();payload=response.read()
        result=json.loads(payload)
        if response.status!=200 or result.get('code')!=0:
            raise RuntimeError(f'Impressora nao confirmou sucesso: HTTP {response.status}; code={result.get("code")}')
        print('A impressora aceitou o pedido de envio com IFS e dois canais.')
        print('Foi solicitado inicio automatico.' if a.start else 'Somente envio; nenhuma impressao foi solicitada.')
        print('Aceitar o pedido nao comprova troca fisica; observe a mudanca na terceira camada.')
    finally:connection.close()

if __name__=='__main__':main()
